package tepsit;

class Buffer {
    private final int[] buffer; 
    private int cnt = 0;    
    private int PutIndice = 0;  
    private int GetIndice = 0;  

    public Buffer(int grandezza) {
        buffer = new int[grandezza];  
    }

    public synchronized void put(int value) throws InterruptedException {
        while (cnt == buffer.length) {
            wait(); 
        }
        buffer[PutIndice] = value; 
        PutIndice = (PutIndice + 1) % buffer.length; 
        cnt++;
        notifyAll(); 
    }

    public synchronized int get() throws InterruptedException {
        while (cnt == 0) {
            wait();  
        }
        int value = buffer[GetIndice];  
        GetIndice = (GetIndice + 1) % buffer.length;
        cnt--;
        notifyAll();  
        return value;
    }
}
