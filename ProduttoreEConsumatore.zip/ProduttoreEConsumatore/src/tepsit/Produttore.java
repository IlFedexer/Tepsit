package tepsit;

class Produttore extends Thread {
    private final Buffer buffer;

    public Produttore(Buffer buffer) {
        this.buffer = buffer;
    }

    public void run() {
        try {
            while (true) {
                int numero = (int) (Math.random() * 1024);  
                buffer.put(numero); 
                System.out.println("Numero generato: " + numero);
                Thread.sleep(100 + (int) (Math.random() * 900));  
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
