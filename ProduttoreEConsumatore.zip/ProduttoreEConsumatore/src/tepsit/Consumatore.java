package tepsit;

class Consumatore extends Thread {
    private final Buffer buffer;
    private int pari = 0;
    private int dispari = 0;

    public Consumatore(Buffer buffer) {
        this.buffer = buffer;
    }

    public void run() {
        try {
            while (true) {
                int numero = buffer.get();  
                System.out.println("Il consumatore legge: " + numero);
                System.out.println(" ");
                if (numero % 2 == 0) {
                    pari++;
                } else {
                    dispari++;
                }
                System.out.println("Numeri pari: " + pari + ", Numeri dispari: " + dispari);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
