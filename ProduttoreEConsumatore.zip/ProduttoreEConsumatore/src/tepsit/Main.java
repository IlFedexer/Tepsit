package tepsit;

public class Main {
    public static void main(String[] args) {
 
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        System.out.print("Inserisci il numero di thread: ");
        int T = scanner.nextInt();
        System.out.print("Inserisci il numero massimo per il conteggio: ");
        int N = scanner.nextInt();

        Buffer buffer = new Buffer(10);

        Produttore produttore = new Produttore(buffer);
        produttore.start();

        Consumatore consumatore = new Consumatore(buffer);
        consumatore.start();

//avvio i threadssssssssssssss
        for (int i = 0; i < T; i++) {
            final int threadId = i + 1;
            new Thread(() -> {
                try {
                    int limite = (int) (Math.random() * (N + 1)); 
                    System.out.println("Thread " + threadId + " conta fino a " + limite);
                    for (int j = 0; j <= limite; j++) {
                        Thread.sleep(120);  
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }).start();
        }
    }
}
