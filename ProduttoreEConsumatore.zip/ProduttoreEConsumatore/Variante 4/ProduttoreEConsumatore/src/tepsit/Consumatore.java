package tepsit;

public class Consumatore extends Thread {
    private final Buffer buffer;
    private final int La500azzaDiddio = 5000;
    private int pari = 0;
    private int dispari = 0;

    public Consumatore(Buffer buffer) {
        this.buffer = buffer;
    }


    public void run() {
        try {
            for (int i = 0; i < La500azzaDiddio; i++) {
                int numero = buffer.get();
                System.out.println("Consumatore ha letto: " + numero);
                System.out.println(" ");
                if (numero % 2 == 0) {
                    pari++;
                } else {
                    dispari++;
                }
                System.out.println("Numeri pari: " + pari + ", Numeri dispari: " + dispari);
                int sleepTime = getRandomSleepTime(new int[]{200, 400, 600, 800, 1000});
                Thread.sleep(sleepTime);
            }
            System.out.println("Il consumatore ha terminato.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private int getRandomSleepTime(int[] times) {
        return times[(int) (Math.random() * times.length)];
    }
}
