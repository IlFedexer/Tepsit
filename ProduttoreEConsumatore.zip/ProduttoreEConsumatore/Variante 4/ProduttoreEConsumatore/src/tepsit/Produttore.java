package tepsit;

public class Produttore extends Thread {
    private final Buffer buffer;
    private final int Spingere500 = 5000;

    public Produttore(Buffer buffer) {
        this.buffer = buffer;
    }

    public void run() {
        try {
            for (int i = 0; i < Spingere500; i++) {
                int numero = (int) (Math.random() * 1024);
                buffer.put(numero);
                System.out.println("Produttore ha generato: " + numero);
                int sleepTime = getRandomSleepTime(new int[]{100, 250, 500, 1000});
                Thread.sleep(sleepTime);
            }
            System.out.println("Produttore ha terminato.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private int getRandomSleepTime(int[] times) {
        return times[(int) (Math.random() * times.length)];
    }
}
