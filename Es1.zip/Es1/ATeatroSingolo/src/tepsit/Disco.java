package tepsit;

public class Disco {
    private static final int Massimo = 100;
    private static int Adesso = 0;

    public synchronized void enter() throws InterruptedException {
        while (Adesso >= Massimo) {
            wait();
        }
        Adesso++;
        System.out.println("Una persona è entrata. Persone attualmente dentro: " + Adesso);
        notifyAll();
    }

    public synchronized void exit() throws InterruptedException {
        while (Adesso <= 0) {
            wait();
        }
        Adesso--;
        System.out.println("Una persona è uscita. Persone attualmente dentro: " + Adesso);
        notifyAll();
    }

    public static void monitorCount() {
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(1000);
                    System.out.println("Numero attuale di persone nella discoteca: " + Adesso);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }).start();
    }
}
