package tepsit;

public class Main {
    public static void main(String[] args) {
        Disco disco = new Disco();
        Disco.monitorCount();

        for (int i = 0; i < 10; i++) {
            new Persona(disco).start();
        }
    }
}
