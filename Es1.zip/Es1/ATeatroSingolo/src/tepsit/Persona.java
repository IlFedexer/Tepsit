package tepsit;

import java.util.Random;

public class Persona extends Thread {
    private final Disco disco;

    public Persona(Disco disco) {
        this.disco = disco;
    }

    @Override
    public void run() {
        Random random = new Random();
        while (true) {
            try {
                disco.enter();
                Thread.sleep(random.nextInt(5000) + 1000);
                disco.exit();
                Thread.sleep(random.nextInt(3000) + 1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
