
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class TestServlet extends HttpServlet {
	
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain");
        response.getWriter().write("Ciao Eleonora, questa è la tua API REST!");
    }
}
