package tepsit;

public class Consumatore extends Thread {
    private final Buffer buffer;
    private int countNegativi = 0;
    private int[] ultimiPositivi = new int[5];
    private int PositivIndex = 0; 
    private int numPositivi = 0; 

    public Consumatore(Buffer buffer) {
        this.buffer = buffer;
    }


    public void run() {
        try {
            while (true) {
                int numero = buffer.get();
                
                if (numero < 0) {
                    countNegativi++;
                } else {
                    
                    ultimiPositivi[PositivIndex] = numero;
                    PositivIndex = (PositivIndex + 1) % 5; 
                    if (numPositivi < 5) {
                        numPositivi++; 
                    }
                }

                System.out.println("Consumatore ha letto: " + numero);
                System.out.println("Negativi contati: " + countNegativi);
                System.out.println("Media ultimi 5 positivi: " + calcolaMediaPositivi());

                Thread.sleep(100); 
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private double calcolaMediaPositivi() {
        if (numPositivi == 0) return 0;  
        int somma = 0;
        for (int i = 0; i < numPositivi; i++) {
            somma += ultimiPositivi[i];
        }
        return (double) somma / numPositivi; 
    }
}

