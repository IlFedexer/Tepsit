package tepsit;

public class Buffer {
    private final int[] buffer;
    private int Contatorone = 0;
    private int PutIndice = 0;
    private int GetIndice = 0;

    public Buffer(int size) {
        buffer = new int[size];
    }

    public synchronized void put(int value) throws InterruptedException {
        while (Contatorone == buffer.length) {
            wait(); 
        }
        buffer[PutIndice] = value;
        PutIndice = (PutIndice + 1) % buffer.length;
        Contatorone++;
        notifyAll();  
    }

    public synchronized int get() throws InterruptedException {
        while (Contatorone == 0) {
            wait();  
        }
        int value = buffer[GetIndice];
        GetIndice = (GetIndice + 1) % buffer.length;
        Contatorone--;
        notifyAll();  
        return value;
    }
}
