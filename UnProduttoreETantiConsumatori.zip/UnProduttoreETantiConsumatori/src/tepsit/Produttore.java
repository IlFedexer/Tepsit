package tepsit;

public class Produttore extends Thread {
    private final Buffer buffer;

    public Produttore(Buffer buffer) {
        this.buffer = buffer;
    }


    public void run() {
        try {
            while (true) {
                int numero = (int) (Math.random() * 2048) - 1024;
                buffer.put(numero);
                System.out.println("Il produttore ha generato: " + numero);
                
                if (numero >= 0) {
                    Thread.sleep((numero / 100) * 50);  
                } else {
                    Thread.sleep(200); 
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
