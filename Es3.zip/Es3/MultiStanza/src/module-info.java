/**
 * 
 */
/**
 * 
 */
module MultiStanza {
}