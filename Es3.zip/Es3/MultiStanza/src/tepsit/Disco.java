package tepsit;

public class Disco {
    private static final int NumPiste = 4;
    private final int[] piste;

    public Disco() {
        piste = new int[NumPiste];
    }

    public synchronized void entraInPista(int pista, int numeroPersone) throws InterruptedException {
        piste[pista] += numeroPersone;
        System.out.println(numeroPersone + " persone sono entrate in pista " + pista);
    }

    public synchronized void esciDaPista(int pista, int numeroPersone) throws InterruptedException {
        piste[pista] -= numeroPersone;
        if (piste[pista] < 0) {
            piste[pista] = 0;
        }
        System.out.println(numeroPersone + " persone sono uscite da pista " + pista);
    }

    public synchronized void cambiaPista(int pistaAttuale, int nuovaPista, int numeroPersone) throws InterruptedException {
        esciDaPista(pistaAttuale, numeroPersone);
        entraInPista(nuovaPista, numeroPersone);
    }

    public void monitorPiste() {
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(500);
                    synchronized (this) {
                        System.out.println("Numero attuale di persone su ogni pista:");
                        for (int i = 0; i < NumPiste; i++) {
                            System.out.println("Pista " + i + ": " + piste[i] + " persone");
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }).start();
    }
}
