package tepsit;

import java.util.Random;

public class Gruppo extends Thread {
    private final Disco disco;
    private final int numeroPersone;
    private int pistaAttuale;
    private final Random random = new Random();

    public Gruppo(Disco disco, int numeroPersone) {
        this.disco = disco;
        this.numeroPersone = numeroPersone;
        this.pistaAttuale = random.nextInt(4);
    }

    @Override
    public void run() {
        while (true) {
            try {
                disco.entraInPista(pistaAttuale, numeroPersone);
                Thread.sleep(random.nextInt(3000) + 1000);
                if (random.nextBoolean()) {
                    disco.esciDaPista(pistaAttuale, numeroPersone);
                    Thread.sleep(random.nextInt(2000) + 1000);
                    disco.entraInPista(pistaAttuale, numeroPersone);
                } else {
                    int nuovaPista = random.nextInt(4);
                    while (nuovaPista == pistaAttuale) {
                        nuovaPista = random.nextInt(4);
                    }
                    disco.cambiaPista(pistaAttuale, nuovaPista, numeroPersone);
                    pistaAttuale = nuovaPista;
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
