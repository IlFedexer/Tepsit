package tepsit;

public class Main {
    public static void main(String[] args) {
        Disco disco = new Disco();
        disco.monitorPiste();

        for (int i = 0; i < 7; i++) {
            int numeroPersoneNelGruppo = (i + 1) * 5;
            new Gruppo(disco, numeroPersoneNelGruppo).start();
        }
    }
}
