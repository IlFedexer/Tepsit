package tepsit;

import java.util.Random;

public class Gruppo extends Thread {
    private final Disco disco;
    private final int Grandezza;

    public Gruppo(Disco disco, int Grandezza) {
        this.disco = disco;
        this.Grandezza = Grandezza;
    }

    @Override
    public void run() {
        Random random = new Random();
        while (true) {
            try {
                disco.enter(Grandezza);
                Thread.sleep(random.nextInt(3000) + 1000);
                disco.exit(Grandezza);
                Thread.sleep(random.nextInt(3000) + 1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
