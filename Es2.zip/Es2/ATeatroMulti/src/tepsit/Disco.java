package tepsit;


public class Disco {
    private static final int Massimo = 161;
    private static int Adesso = 0;
    private static final int LimiteAttesa = 10; 
    private static final int[] GruppiAttesa = new int[LimiteAttesa];
    private static int Attesa = 0;

    public synchronized boolean enter(int GrandezzaGruppo) throws InterruptedException {
        while (Adesso + GrandezzaGruppo > Massimo) {
            if (Attesa < LimiteAttesa) {
                GruppiAttesa[Attesa++] = GrandezzaGruppo; 
                System.out.println("Gruppo di " + GrandezzaGruppo + " in attesa di entrare.");
            }
            wait();
        }
        Adesso += GrandezzaGruppo;
        System.out.println(GrandezzaGruppo + " persone sono entrate. Persone attualmente dentro: " + Adesso);
        notifyAll();
        return true;
    }

    public synchronized boolean exit(int GrandezzaGruppo) throws InterruptedException {
        Adesso -= GrandezzaGruppo;
        System.out.println(GrandezzaGruppo + " persone sono uscite. Persone attualmente dentro: " + Adesso);
        notifyAll();
        return true;
    }

    public static void monitorCount() {
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(1000);
                    System.out.println("Persone attualmente dentro: " + Adesso);
                    System.out.print("Gruppi in attesa: ");
                    for (int i = 0; i < Attesa; i++) {
                        System.out.print(GruppiAttesa[i] + " ");
                    }
                    System.out.println();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }).start();
    }

    public synchronized void GruppiAttesa() {
        while (Attesa > 0 && Adesso < Massimo) {
            int GrandezzaGruppo = GruppiAttesa[0];
            for (int i = 1; i < Attesa; i++) {
                GruppiAttesa[i - 1] = GruppiAttesa[i]; 
            }
            Attesa--; 
            Adesso += GrandezzaGruppo;
            System.out.println(GrandezzaGruppo + " persone sono entrate dalla lista di attesa. Persone attualmente dentro: " + Adesso);
        }
        notifyAll();
    }
}